package com.iAcademia.webview;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MapActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        webView = (WebView)findViewById(R.id.webview);



        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.google.com/maps/d/u/0/edit?mid=11W0Y5tJIrnXLFErR3xA3EsVsEvNkXexj&ll=20.500229297871922%2C79.92082018150472&z=4");

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
    }
}
