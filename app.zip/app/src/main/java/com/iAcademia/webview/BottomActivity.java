package com.iAcademia.webview;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class BottomActivity extends AppCompatActivity {
    private TextView mTextMessage;
    private WebView webView;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Intent intent = new Intent(BottomActivity.this,slackActivity.class);
                    startActivity(intent);
                    return true;
                case R.id.navigation_dashboard:
                    Intent intent1 = new Intent(BottomActivity.this,Webmail.class);
                    startActivity(intent1);
                    return true;
                case R.id.navigation_notifications:
                   Intent intent2 =new Intent(BottomActivity.this,Yammer.class);
                   startActivity(intent2);
                    return true;
                case R.id.navigation_map:
                    Intent intent3 = new Intent(BottomActivity.this,MapActivity.class);
                    startActivity(intent3);
                    return true;
                case R.id.navigation_home1:
                    Intent intent4 = new Intent(BottomActivity.this,HomeActivity.class);
                    startActivity(intent4);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom);
        ActionBar ab = getSupportActionBar();
        ab.setTitle("iAcademia");

        webView = (WebView)findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://iacademia.org/login");

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        BottomNavigationView navView = findViewById(R.id.nav_view);
        mTextMessage = findViewById(R.id.message);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
