package com.iAcademia.webview;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class slackActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String Url = "https:/" + "" + "/slack.onelink.me/FQG3?af_sub1=%2Fintl%2Fen-in%2F&af_slk_web_endpoint=%2Fintl%2Fen-in%2F&af_slk_web_visitor_uid=.8pgqy66qwo0otn9noqncwpjhs&pid=slack_web";
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(Url));
        startActivity(intent);
    }
}
